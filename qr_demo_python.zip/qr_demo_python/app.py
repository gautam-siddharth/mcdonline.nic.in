from flask import Flask, render_template, request, url_for
import qrcode
from pathlib import Path
from urllib.parse import urlencode

app = Flask(__name__)

BASE_DIR = Path(__file__).resolve().parent
QR_DIR = BASE_DIR / "static"
QR_DIR.mkdir(exist_ok=True)

# Demo/test data only. Do not use this project to represent an official certificate.
CERTIFICATE = {
    "name": "YASHVIT KUMAR",
    "event": "BIRTH",
    "application_no": "0123-2901286793",
    "submit_date": "29/01/2023",
    "event_date": "25/11/2022",
    "status": "Certificate Generated",
}

# Fictional values for the separate certificate-style preview page.
DEMO_BIRTH_RECORD = {
    "registration_no": "MCDOLIR-0122-0112199889",
    "name": "YASHVIT KUMAR",
    "gender": "MALE",
    "date_of_birth": "25/11/2022",
    "mother_name": "ANJALI",
    "father_name": "SIDDHARTH KUMAR GAUTAM",
    "place_of_birth": "HOLY FAMILY HOSPITAL OKHLA ROAD, NEW DELHI SOUTH OKHLA SOUTH EAST DELHI INDIA 110025",
    "permanent_address": "HOUSE NO. F - 204/D, STREET NO. 08, MOLARBAND EXTENSION,BADARPUR, SOUTH DELHI INDIA 110044",
    "date_of_registration": "01/12/2022",
}

@app.route("/")
def home():
    return render_template("certificate.html", certificate=CERTIFICATE)

@app.route("/certificate-preview")
def certificate_preview():
    return render_template("certificate_preview.html", certificate=DEMO_BIRTH_RECORD)

@app.route("/verify")
@app.route("/certificate.html", endpoint="certificate_page")
def verify():
    # Values can come from the QR URL, but defaults are supplied for demo use.
    certificate = CERTIFICATE.copy()
    for key in certificate:
        if request.args.get(key):
            certificate[key] = request.args.get(key)

    # Always show an explicit demo label.
    certificate["demo"] = True
    return render_template("certificate.html", certificate=certificate)

@app.route("/generate-qr")
def generate_qr():
    # Default to this Flask server so /generate-qr works locally.  Supply
    # ?base_url=https://YOUR_PUBLIC_DOMAIN after deployment to encode a public URL.
    base_url = request.args.get("base_url", request.url_root).strip().rstrip("/")

    query = urlencode(CERTIFICATE)
    certificate_path = url_for("certificate_page")
    verification_url = f"{base_url}{certificate_path}?{query}"

    qr_path = QR_DIR / "verification_qr.png"
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=10,
        border=4,
    )
    qr.add_data(verification_url)
    qr.make(fit=True)

    image = qr.make_image(fill_color="black", back_color="white")
    image.save(qr_path)

    return render_template(
        "qr.html",
        verification_url=verification_url,
        qr_file=url_for("static", filename="verification_qr.png"),
    )

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000, debug=True)
